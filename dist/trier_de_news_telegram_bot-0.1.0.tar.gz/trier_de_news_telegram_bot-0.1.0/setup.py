# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['trier_de_news_telegram_bot']

package_data = \
{'': ['*']}

install_requires = \
['click>=8.1.3,<9.0.0',
 'feedparser>=6.0.10,<7.0.0',
 'python-telegram-bot>=13.15,<14.0']

setup_kwargs = {
    'name': 'trier-de-news-telegram-bot',
    'version': '0.1.0',
    'description': '',
    'long_description': '#Trier.de News Telegram Bot\n\nThis is a very simple telegram bot the reads the RSS feed of the [Website of the city of Trier](https://www.trier.de) and posts new entries to a telegram group.',
    'author': 'Christopher Perrin',
    'author_email': 'cperrin88@users.noreply.github.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.11,<4.0',
}


setup(**setup_kwargs)
