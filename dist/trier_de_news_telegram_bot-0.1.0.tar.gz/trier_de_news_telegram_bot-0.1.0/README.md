#Trier.de News Telegram Bot

This is a very simple telegram bot the reads the RSS feed of the [Website of the city of Trier](https://www.trier.de) and posts new entries to a telegram group.